CREATE Table BUSINESS_CHECKIN as SELECT BUSINESS.Business_id as BID, BUSINESS.name, BUSINESS.stars, BUSINESS.Review_count, BUSINESS.attributes,
CHECKIN.date as Cdate, CHECKIN.business_id as CID
FROM BUSINESS, CHECKIN
WHERE BID=CID;     

//Data_warehousing

create or replace table fact_table as SELECT BUSINESS_CHECKIN.BID as business_checkin_key, BUSINESS_CHECKIN.Cdate as date_of_checkin, BUSINESS_CHECKIN.name as business_name, BUSINESS_CHECKIN.stars as business_ratings,
USER.User_ID as user_key, USER.friends as friends_of_business_owner, USER.fans as fans_of_business, USER.review_count as no_of_reviews,
DATA_INTEGRATION.review_business_id as data_integration_key, DATA_INTEGRATION.Rdate as date_of_review,
DATA_INTEGRATION.REVIEW_RATING as ratings, DATA_INTEGRATION.average_temperature as temperature, DATA_INTEGRATION.precipitation,
COVID_FEATURES.business_id as covid_features_key,COVID_FEATURES.delivery_or_takeout, COVID_FEATURES.virtual_services_offered, COVID_FEATURES.grubhub_enabled, 
TIP.user_id as tip_key, TIP.date as date_of_tip, TIP.text as tip_text, TIP.compliment_count as no_of_tips, TIP.business_id as TID
FROM BUSINESS_CHECKIN, USER, COVID_FEATURES, DATA_INTEGRATION, TIP
WHERE covid_features_key=business_checkin_key AND data_integration_key=user_key AND Rdate=date_of_tip AND business_checkin_key=data_integration_key AND TID=covid_features_key;