create table BUSINESS2(
BUSINESS2 variant
);

copy into BUSINESS2 (BUSINESS2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/yelp_academic_dataset_business.json.gz)
FILE_FORMAT = 'JSON_MASTER';

create table CHECKIN2(
CHECKIN2 variant
);

copy into CHECKIN2 (CHECKIN2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/yelp_academic_dataset_checkin.json.gz)
FILE_FORMAT = 'JSON_MASTER';

create table TIP2(
TIP2 variant
);

copy into TIP2 (TIP2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/yelp_academic_dataset_tip.json.gz)
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;

create table USER2(
USER2 variant
);

copy into USER2 (USER2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/yelp_academic_dataset_user.json.gz)
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;

create COVID_FEATURES2 BUSINESS2(
COVID_FEATURES2 variant
);

copy into COVID_FEATURES2 (COVID_FEATURES2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/zyelp_academic_dataset_covid_features.json.gz)
FILE_FORMAT = 'JSON_MASTER';

#Previously Review JSON file was equally split into 3 pieces to dock into user stage

create table REVIEW2(
REVIEW2 variant
);

copy into REVIEW2(REVIEW2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/1yelp_academic_dataset_review.json.gz)
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;
                     
copy into REVIEW2(REVIEW2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/22yelp_academic_dataset_review.json.gz)
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;
                     
copy into REVIEW2(REVIEW2)
from (select parse_json($1) from @WEATHER_AND_RESTAURANTS/333yelp_academic_dataset_review.json.gz)
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;

copy into TEMPERATURE (TEMPERATURE)
from @WEATHER_AND_RESTAURANTS/33yelp_academic_dataset_temperature.json.gz
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;

copy into PRECIPITATION (PRECIPITATION)
from @WEATHER_AND_RESTAURANTS/33yelp_academic_dataset_precipitation.json.gz
FILE_FORMAT = 'JSON_MASTER'
ON_ERROR=CONTINUE;


