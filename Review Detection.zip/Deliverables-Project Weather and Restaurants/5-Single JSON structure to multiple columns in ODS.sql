create table BUSINESS as select parse_json($1):business_id as business_id, parse_json($1):name as name, parse_json($1):address as address, parse_json($1):city as city,
parse_json($1):state as state, parse_json($1):postal_code as postal_code, parse_json($1):latitude as latitude, parse_json($1):longitude as longitude, parse_json($1):stars as stars,
parse_json($1):review_count as review_count, parse_json($1):is_open as is_open, parse_json($1):categories as categories, parse_json($1):hours as hours, parse_json($1):attributes as attributes
from BUSINESS2;
                     
create table CHECKIN3 as select parse_json($1):business_id, parse_json($1):date from CHECKIN2;
                                       
create table CHECKIN4 as select business_id,c.value::string as date
from CHECKIN3,
lateral flatten(input=>split(date, ',')) c;
                     
create table CHECKIN (date, business_id) 
as select to_date(date),business_id from CHECKIN4;
                                     
create table TIP as select to_date(parse_json($1):date) as date, parse_json($1):user_id as user_id,
parse_json($1):business_id as business_id, parse_json($1):text as text, 
parse_json($1):compliment_count as compliment_count from TIP2;
                     
create table USER as select parse_json($1):user_id as user_id, parse_json($1):name as name,
parse_json($1):review_count as review_count, parse_json($1):yelping_since as yelping_since,
parse_json($1):useful as useful, parse_json($1):funny as funny, parse_json($1):cool as cool,
parse_json($1):elite as elite, parse_json($1):friends as friends, parse_json($1):fans as fans,
parse_json($1):average_stars as average_stars, parse_json($1):compliment_hot as compliment_hot,
parse_json($1):compliment_more as compliment_more,
parse_json($1):compliment_proile as compliment_profile, parse_json($1):compliment_cute as compliment_cute,
parse_json($1):compliment_list as compliment_list, parse_json($1):compliment_note as compliment_note,
parse_json($1):compliment_plain as compliment_plain, parse_json($1):compliment_cool as compliment_cool,
parse_json($1):compliment_funny as compliment_funny, parse_json($1):compliment_writer as compliment_writer,
parse_json($1):compliment_photos as compliment_photos from USER2;                   
                 
create table REVIEW as select to_date(parse_json($1):date) as date, parse_json($1):user_id as user_id,
parse_json($1):review_id as review_id, parse_json($1):business_id as business_id, 
parse_json($1):stars as stars, parse_json($1):useful as useful, parse_json($1):funny as funny,
parse_json($1):cool as cool, parse_json($1):text as text from REVIEW2;                  
                  

create table COVID_FEATURES as select parse_json($1):business_id as business_id,
parse_json($1):highlights as highlights, parse_json($1):delivery_or_takeout as delivery_or_takeout,
parse_json($1):grubhub_enabled as grubhub_enabled, parse_json($1):call_to_action_enabled as call_to_action_enabled,
parse_json($1):request_a_quote_enabled as request_a_quote_enabled, parse_json($1):covid_banner as covid_banner,
parse_json($1):temporary_closed_until as temporary_closed_until, parse_json($1):virtual_services_offered as virtual_services_offered
from COVID_FEATURES2;
