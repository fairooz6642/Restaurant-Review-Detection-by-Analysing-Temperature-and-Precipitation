SELECT fact_table.business_name, fact_table.temperature, fact_table.precipitation, fact_table.ratings
from fact_table;