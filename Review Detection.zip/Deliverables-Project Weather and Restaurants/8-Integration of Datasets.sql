//The dates of TEMPERATURE and PRESSURE were already converted to the proper formats from excel in the format 'yyyy-mm-dd' using formula '=TEXT(A2,"0000-00-00")'

create or replace table TEMPERATURE_2 as select date, ((maximum + minimum)/2) as average_temperature from TEMPERATURE;

CREATE Table DATA_INTEGRATION as SELECT 
TEMPERATURE_2.date as TEMP_DATE, TEMPERATURE_2.average_temperature,
PRECIPITATION.date as PREC_DATE, PRECIPITATION.precipitation, REVIEW.user_id,
REVIEW.review_id, REVIEW.business_id as REVIEW_business_id, REVIEW.stars as REVIEW_RATING, REVIEW.date as Rdate
FROM TEMPERATURE_2, PRECIPITATION, REVIEW
WHERE TEMP_DATE=Rdate AND PREC_DATE=Rdate;